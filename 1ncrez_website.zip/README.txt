1NCREZ WEBSITE

Files:
- index.html — the website
- profile.jpg — your selected profile photo

HOW TO PUBLISH:
1. Upload both files to a web host.
2. Keep index.html in the main/public folder.
3. Connect a domain such as 1ncrez.com if available.
4. After the site is live, submit the homepage to Google Search Console.
5. Keep your name "Increase Okorie" and creator name "1ncrez" consistent on your public profiles.

The site includes basic SEO metadata and Schema.org Person structured data linking your YouTube, TikTok, and Instagram profiles.
